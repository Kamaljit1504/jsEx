var a=prompt("enter a num");

if(a%2==0)
{
  alert("No is even");
}
else {
  alert("No is odd");
}
