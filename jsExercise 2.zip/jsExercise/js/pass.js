
pas();

function pas()
{
  var pass =prompt("entre you pass");
  if(pass == 15)
  {

    alert("Matched");
  }
  else
    {
    alert(" TRy Again");
  pas1();
    }
}
function pas1()
{
  var pass =prompt("entre you pass");

  if(pass == 15)
  {
    alert("Matched");
  }
  else
    {
    alert(" TRy Again");
  pas();
    }
}
