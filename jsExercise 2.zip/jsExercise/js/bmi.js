var w =prompt("Enter you Weight in kg");
var h =prompt("Enter youheightt in m");
BMI();

function BMI()
{

  var bmi= w/h*h;
  alert("BMI="+bmi)

}
